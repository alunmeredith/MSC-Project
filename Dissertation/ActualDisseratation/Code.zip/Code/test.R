library(dplyr)
library(poweRlaw)
load("dat/powerLawFits.rdata")

sv <- function() {save(pl, pl_Examiner, pl_Other, file = "dat/powerLawFitsBS.rdata")}

pl[[2001-1975]]$boostraps$ln <- bootstrap_p( pl[[2001-1975]]$distributions$ln, threads = 8, no_of_sims = 1000); sv()
pl_Other[[2001-1975]]$boostraps$ln <- bootstrap_p( pl_Other[[2001-1975]]$distributions$ln, threads = 8, no_of_sims = 1000); sv()
pl_Examiner[[2001-1975]]$boostraps$ln <- bootstrap_p( pl_Examiner[[2001-1975]]$distributions$ln, threads = 8, no_of_sims = 1000); sv()

pl[[2001-1975]]$boostraps$pl <- bootstrap( pl[[2001-1975]]$distributions$pl, threads = 8, no_of_sims = 1000); sv()
pl_Other[[2001-1975]]$boostraps$pl <- bootstrap( pl_Other[[2001-1975]]$distributions$pl, threads = 8, no_of_sims = 1000); sv()
pl_Examiner[[2001-1975]]$boostraps$pl <- bootstrap( pl_Examiner[[2001-1975]]$distributions$pl, threads = 8, no_of_sims = 1000); sv()

pl[[2001-1975]]$boostraps$exp <- bootstrap( pl[[2001-1975]]$distributions$exp, threads = 8, no_of_sims = 1000); sv()
pl_Examiner[[2001-1975]]$boostraps$exp <- bootstrap( pl_Examiner[[2001-1975]]$distributions$exp, threads = 8, no_of_sims = 1000); sv()
pl_Other[[2001-1975]]$boostraps$exp <- bootstrap( pl_Other[[2001-1975]]$distributions$exp, threads = 8, no_of_sims = 1000); sv()

pl[[2001-1975]]$boostraps$pois <- bootstrap( pl[[2001-1975]]$distributions$pois, threads = 8, no_of_sims = 1000); sv()
pl_Examiner[[2001-1975]]$boostraps$pois <- bootstrap( pl_Examiner[[2001-1975]]$distributions$pois, threads = 8, no_of_sims = 1000); sv()
pl_Other[[2001-1975]]$boostraps$pois <- bootstrap( pl_Other[[2001-1975]]$distributions$pois, threads = 8, no_of_sims = 1000); sv()
